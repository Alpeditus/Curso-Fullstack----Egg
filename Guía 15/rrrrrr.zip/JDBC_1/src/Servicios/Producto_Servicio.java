/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Servicios;

import Persistencia.Fabricante_DAO;
import Persistencia.Producto_DAO;
import java.util.Scanner;


public class Producto_Servicio {

    private Producto_DAO dao;
    private Fabricante_DAO daoF;                  
    Scanner leer = new Scanner(System.in);

    public Producto_Servicio() {
        this.dao = new Producto_DAO();
        this.daoF = new Fabricante_DAO();
    }

   public  void listarNombresProductos() throws Exception{
       dao.nombreDeProductos();
   }
    
   public void listarNombresPreciosProductos() throws Exception{
       dao.nombre_Y_Precio();
   }
   
   public void productosPorPrecio() throws Exception{
       dao.productosEntre_120_202();
   } 
   
   public void listarPortatiles() throws Exception {
    dao.portatiles();
}
   
   public void mostrarProductoMasBarato() throws Exception {
    dao.masBarato();
}
   
   public void ingresarUnProducto() throws Exception{
       System.out.println("Ingrese Nombre del Nuevo Producto");
       String nombre = leer.nextLine();
       System.out.println("Ingrese Precio del Nuevo Producto");
       double precio = leer.nextDouble();
       System.out.println("Ingrese Código del Fabricante");
       int codigoFabricante = leer.nextInt();
       dao.ingresar_Producto(nombre, precio, codigoFabricante);
   }
   
    public void editarUnProducto() throws Exception {
        boolean existe = false;
        int codigo = 0;
        do {            
            System.out.println("Ingrese Código de Producto ");
            codigo = leer.nextInt();
            existe = dao.existeProducto(codigo);
        } while (existe);
        
        dao.datosDeUnProducto(codigo);
        
        
    }
    
    public void mostrarMenu() {
        System.out.println("----- Menú de Modificación de Producto -----");
        System.out.println("1. Modificar Nombre del Producto");
        System.out.println("2. Modificar Precio del Producto");
        System.out.println("3. Modificar Código de Fabricante");
        System.out.println("4. Guardar y Salir");
        System.out.println("5. Salir sin Guardar");
        System.out.print("Ingrese una opción: ");
    }
    
    public  void modificarDatos(int codigo, String nombre, double precio, int codigo_fabricante) throws Exception{
        
        int codigoProducto = codigo;
        String nombreProducto = nombre;
        double precioProducto = precio;
        int codigoFabricante = codigo_fabricante;

        boolean salir = false;
        while (!salir) {
            mostrarMenu();
            int opcion = leer.nextInt();
            leer.nextLine(); 

            switch (opcion) {
                case 1:
                    System.out.print("Ingrese el nuevo nombre del producto: ");
                    nombreProducto = leer.nextLine();
                    break;
                case 2:
                    System.out.print("Ingrese el nuevo precio del producto: ");
                    precioProducto = leer.nextDouble();
                    break;
                case 3:
                    System.out.print("Ingrese el nuevo código de fabricante: ");
                    codigoFabricante = leer.nextInt();
                    break;
                case 4:
                    // Guardar los cambios en el producto
                    dao.modificarProducto(codigoProducto, nombreProducto, precioProducto, codigoFabricante);
                    System.out.println("¡Producto modificado exitosamente!");
                    salir = true;
                    break;
                case 5:
                    // Salir del programa sin guardar los cambios
                    System.out.println("Saliendo del programa sin guardar los cambios...");
                    salir = true;
                    break;
                default:
                    System.out.println("Opción inválida. Por favor, ingrese un número válido.");
            }
        }
    }
    }

    

