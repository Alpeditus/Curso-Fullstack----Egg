
package Persistencia;

import Servicios.Producto_Servicio;
import java.sql.ResultSet;

public final class Producto_DAO extends DAO {
    
    public void nombreDeProductos() throws Exception {
        try {
            resultado = tablaProducto();
            while (resultado.next()) {
                int codigo = resultado.getInt(1);
                String nombre = resultado.getString(2);
                System.out.println(codigo + " --> " + nombre);
               }
        } catch (Exception e) {
            cerrarDB();
            throw e;
        } finally {
            cerrarDB();
        }
    }
    
    public void nombre_Y_Precio() throws Exception {
        try {
            resultado = tablaProducto();
            while (resultado.next()) {
                int codigo = resultado.getInt(1);
                String nombre = resultado.getString(2);
                double precio = resultado.getDouble(3);
                System.out.println(codigo + " : " + nombre + ". Precio $ " + precio);
            }
        } catch (Exception e) {
            cerrarDB();
            throw e;
        } finally {
            cerrarDB();
        }
    }

    
    public ResultSet tablaProducto() throws Exception {
        String sql = "SELECT  * FROM producto";
        consultarDB(sql);
        return resultado;
    }
    
    public void productosEntre_120_202() throws Exception{
        String sql = "SELECT nombre, precio FROM producto WHERE precio BETWEEN 120 AND 202";
        try {
            consultarDB(sql);
            while (resultado.next()) {
                String nombre = resultado.getString(1);
                double precio = resultado.getDouble(2);
                System.out.println("Producto --> " + nombre + " Precio --> " + precio);
            }
        } catch (Exception e) {
            cerrarDB();
            throw e;
        } finally {
            cerrarDB();
        }
    }
    
    public void portatiles() throws Exception {
      String sql = "SELECT nombre FROM producto WHERE nombre LIKE '%Portátil%'";
        try {
            consultarDB(sql);
            while (resultado.next()) {
                String nombre = resultado.getString(1);
                System.out.println("Producto --> " + nombre);
            }
        } catch (Exception e) {
            cerrarDB();
            throw e;
        } finally {
            cerrarDB();
        }
    }
    
    public void masBarato() throws Exception {
        String sql = "SELECT nombre, precio FROM producto ORDER BY precio ASC LIMIT 1";
        try {
            consultarDB(sql);
            while (resultado.next()) {
                String nombre = resultado.getString(1);
                double precio = resultado.getDouble(2);
                System.out.println(nombre + ", Precio $ " + precio);
            }
        } catch (Exception e) {
            cerrarDB();
            throw e;
        } finally {
            cerrarDB();
        }
    }
    
    public void ingresar_Producto(String nombre, double precio, int codigoFabricante) throws Exception  {
      String sql = "INSERT INTO producto (nombre, precio, codigo_fabricante) VALUES ('" + nombre + "', " + precio + ", " + codigoFabricante + ")";
        try {
            insertarModificarEliminar_DB(sql);
        } catch (Exception e) {
            cerrarDB();
            throw e;
        }
        finally {
            System.out.println("Producto Agregado correctamente");
            cerrarDB();
        }
    }
    
    public boolean existeProducto(int codigo) throws Exception {
        String sql = "SELECT codigo FROM producto";
        try {
            consultarDB(sql);
            while (resultado.next()) {
                if (resultado.getInt(1) == codigo) {
                    return false;
                }
            }
        } catch (Exception e) {
            cerrarDB();
            throw e;
        } finally {
            cerrarDB();
            
        }
        System.out.println("Ese Código NO Existe");
        return true;
    }
    
    public void datosDeUnProducto(int codigo) throws Exception {
        String sql = "SELECT * FROM producto WHERE codigo = " + codigo;

        try {
            consultarDB(sql);
            if (resultado.next()) { 
                int codigoProducto = resultado.getInt(1);
                String nombre = resultado.getString(2);
                double precio = resultado.getDouble(3);
                int codigoFabricante = resultado.getInt(4);
                System.out.println("Datos del Producto a Modificar");
                System.out.println("Código: " + codigoProducto);
                System.out.println("Nombre: " + nombre);
                System.out.println("Precio: " + precio);
                System.out.println("Código de Fabricante: " + codigoFabricante);
                System.out.println("-----------------------");
                Servicios.Producto_Servicio ps = new Producto_Servicio();
                ps.modificarDatos(codigoProducto, nombre, precio, codigoFabricante);
            }

            }catch (Exception e) {
            cerrarDB();
            throw e;
        }
            finally {
            cerrarDB();
        }
    }
    
    public void modificarProducto(int codigoProducto, String nombreProducto, double precioProducto, int codigoFabricante) throws Exception{
        String sql = "UPDATE producto SET nombre = '" + nombreProducto + "', precio = " + precioProducto + ", codigo_fabricante = " + codigoFabricante + " WHERE codigo = " + codigoProducto;
        try {
            insertarModificarEliminar_DB(sql);
        } catch (Exception e) {
            cerrarDB();
            throw e;
        }
        finally {
            System.out.println("Producto Modificado");
            cerrarDB();
        }
    }
    }

    
        

       
    

        
     