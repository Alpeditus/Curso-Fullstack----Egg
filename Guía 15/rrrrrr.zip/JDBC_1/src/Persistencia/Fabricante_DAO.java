/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Persistencia;

/**
 *
 * @author litit
 */
public final class Fabricante_DAO extends DAO {
    
    public void nuevoFabricante(String nombre1) throws Exception  {
      String sql = "INSERT INTO fabricante (nombre) VALUES ('" + nombre1 + "')";
        System.out.println(sql);
        try {
            insertarModificarEliminar_DB(sql);
        } catch (Exception e) {
            cerrarDB();
            throw e;
        }
        finally {
            System.out.println("Se Agregó un nuevo Fabricante");
            cerrarDB();
        }
    }
    
}
