package jdbc_1;
import Persistencia.Producto_DAO;
import Servicios.Fabricante_Servicio;
import Servicios.Producto_Servicio;
import java.util.InputMismatchException;
import java.util.Scanner;


public class JDBC_1 {

   
    public static void main(String[] args) throws Exception {
        Scanner leer = new Scanner(System.in);
        Producto_DAO producto_DAO = new Producto_DAO();
        Servicios.Producto_Servicio producto_Servicio = new Producto_Servicio();
        Servicios.Fabricante_Servicio fabricante_Servicio = new Fabricante_Servicio();

      

        
        int opcion;

        do {
            System.out.println("-----------------------------------------------------");
            System.out.println("                    Menú Principal                    ");
            System.out.println("-----------------------------------------------------");
            System.out.println("1. Nombres de todos los productos");
            System.out.println("2. Nombres y precios de todos los productos");
            System.out.println("3. Productos con precio entre 120 y 202");
            System.out.println("4. Portátiles");
            System.out.println("5. Producto más barato");
            System.out.println("6. Ingresar un producto");
            System.out.println("7. Ingresar un fabricante");
            System.out.println("8. Editar un producto");
            System.out.println("9. Salir");
            System.out.println("----------------------------------------------------");
            System.out.print("Ingrese una opción: ");

            try {
                opcion = leer.nextInt();

                switch (opcion) {
                    case 1:
                        System.out.println("");
                        System.out.println("-----------------------------------------------------");
                        System.out.println("----- Nombres de todos los productos -----");
                        producto_Servicio.listarNombresProductos();
                        break;
                    case 2:
                        System.out.println("");
                        System.out.println("-----------------------------------------------------");
                        System.out.println("----- Nombres y precios de todos los productos -----");
                        producto_Servicio.listarNombresPreciosProductos();
                        System.out.println("--------------------------------------------------");
                        break;
                    case 3:
                        System.out.println("");
                        System.out.println("-----------------------------------------------------");
                        System.out.println("----- Productos con precio entre 120 y 202 -----");
                        producto_Servicio.productosPorPrecio();
                        System.out.println("-----------------------------------------------");
                        break;
                    case 4:
                        System.out.println("");
                        System.out.println("-----------------------------------------------------");
                        System.out.println("------------------ Portátiles ----------------------");
                        producto_Servicio.listarPortatiles();
                        System.out.println("---------------------");
                        break;
                    case 5:
                        System.out.println("");
                        System.out.println("-----------------------------------------------------");
                        System.out.println("-------------- Producto más barato -----------");
                        producto_Servicio.mostrarProductoMasBarato();
                        System.out.println("-----------------------------");
                        break;
                    case 6:
                        System.out.println("");
                        System.out.println("-----------------------------------------------------");
                        System.out.println("--------------- Ingresar un producto ------------");
                        producto_Servicio.ingresarUnProducto();
                        break;
                    case 7:
                        System.out.println("");
                        System.out.println("-----------------------------------------------------");
                        System.out.println("----------- Ingresar un fabricante -------------");
                        fabricante_Servicio.ingresarUnFabricante();
                        break;
                    case 8:
                        System.out.println("");
                        System.out.println("-----------------------------------------------------");
                        System.out.println("------------- Editar un producto ---------------");
                        producto_Servicio.editarUnProducto();
                        break;
                    case 9:
                        System.out.println("");
                        System.out.println("¡Hasta luego!");
                        break;
                    default:
                        System.out.println("");
                        System.out.println("Opción inválida. Por favor, intente nuevamente.");
                        break;
                }
            } catch (InputMismatchException e) {
                System.out.println("");
                System.out.println("Entrada inválida. Por favor, ingrese un número válido.");
                leer.nextLine(); 
                opcion = 0; 
            }

            System.out.println();
        } while (opcion != 9);

        leer.close();
    }
}
        
        
    
    


