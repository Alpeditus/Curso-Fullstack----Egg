/*
  Un cine necesita implementar un sistema en el que se puedan cargar peliculas. Para esto,
tendremos una clase Pelicula con el título, director y duración de la película (en horas).
Implemente las clases y métodos necesarios para esta situación, teniendo en cuenta lo
que se pide a continuación:
En el servicio deberemos tener un bucle que crea un objeto Pelicula pidiéndole al usuario
todos sus datos y guardándolos en el objeto Pelicula.
Después, esa Pelicula se guarda una lista de Peliculas y se le pregunta al usuario si quiere
crear otra Pelicula o no.
Después de ese bucle realizaremos las siguientes acciones:
22
• Mostrar en pantalla todas las películas.
• Mostrar en pantalla todas las películas con una duración mayor a 1 hora.
• Ordenar las películas de acuerdo a su duración (de mayor a menor) y mostrarlo en
pantalla.
• Ordenar las películas de acuerdo a su duración (de menor a mayor) y mostrarlo en
pantalla.
• Ordenar las películas por título, alfabéticamente y mostrarlo en pantalla.
• Ordenar las películas por director, alfabéticamente y mostrarlo en pantalla.
 */
package servicios;

import entidades.Pelicula;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 *
 * @author Paulo
 */
public class peliculaServicios {

    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    Scanner leer2 = new Scanner(System.in).useDelimiter("\n");
    Scanner leer3 = new Scanner(System.in).useDelimiter("\n");
    Scanner leer4 = new Scanner(System.in).useDelimiter("\n");
    List<String> listaPeliculas;

    public void cargarPeliculas(ArrayList<Pelicula> peliculas) {


        String titulo;
        String director;
        double duracion;
        String seguir = "s";
        do {
            System.out.print("\nTítulo: ");
            titulo = leer.nextLine();
            System.out.print("Director: ");
            director = leer2.next();
            System.out.print("Duración (en horas): ");
            duracion = leer3.nextDouble();
            peliculas.add(new Pelicula(titulo, director, duracion));
            System.out.print("Desea cargar otra película? (S/N): ");
            seguir = leer4.next();

        } while (seguir.equalsIgnoreCase("s"));
    }

    public void mostrarPeliculas(ArrayList<Pelicula> peliculas) {
//		System.out.println("Mostrando todas las películas");
//		peliculas.forEach((Pelicula) -> System.out.printf("Título: %s\nDirector: %s\nDuración: %.2f\n\n", Pelicula.getTitulo() , Pelicula.getDirector(), Pelicula.getDuracion()));

        for (Pelicula pelis : peliculas) {
            System.out.println(pelis);
        }
    }

    public void mostrarPeliculasMas1hora(ArrayList<Pelicula> peliculas) {
        boolean buscar = false;
        for (int i = 0; i < peliculas.size(); i++) {
            Pelicula p1 = peliculas.get(i);
            if (p1.getDuracion() > 1) {
                System.out.println("Mostrando películas mayores a una hora: ");
                System.out.println(p1.getTitulo());
                System.out.println(p1.getDirector());
                System.out.println(p1.getDuracion());
                buscar = true;
            }
        }
        if (!buscar) {
            System.out.println();
            System.out.println("No se encontro ninguna pelicula con duracion mayor a una hora");
        }
    }
//    Ordenar las películas de acuerdo a su duración (de mayor a menor) y mostrarlo en
//pantalla.
    public void ordenarPorDuracionAscendente(ArrayList<Pelicula> peliculas){
        
        System.out.println("Ordenando por duración, de menor a mayor: ");
        peliculas.sort(Pelicula.odenarPorDuracionAscendente);
        mostrarPeliculas(peliculas);
    }
    
//    Ordenar las películas de acuerdo a su duración (de menor a mayor) y mostrarlo en
//pantalla.
    
    public void ordenarPorDuracionDescendente(ArrayList<Pelicula> peliculas){
        
        System.out.println("Ordenando por duración, de mayor a menor: ");
        peliculas.sort(Pelicula.odenarPorDuracionDescendente);
        mostrarPeliculas(peliculas);
    
    }
    
//    Ordenar las películas por título, alfabéticamente y mostrarlo en pantalla.

    public void ordenarPorTitulo (ArrayList<Pelicula> peliculas){
        
        System.out.println("Ordenando por Titulo: ");
        peliculas.sort(Pelicula.odenarPortituloAsc);
        mostrarPeliculas(peliculas);
    }

//    • Ordenar las películas por director, alfabéticamente y mostrarlo en pantalla.
    
    public void ordenarPorDirector (ArrayList<Pelicula> peliculas){
        
        System.out.println("Ordenando por Director: ");
        peliculas.sort(Pelicula.odenarDirectorAsc);
        mostrarPeliculas(peliculas);
    }
    
}
