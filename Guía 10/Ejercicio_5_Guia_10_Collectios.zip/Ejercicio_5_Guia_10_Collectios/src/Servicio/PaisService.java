/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servicio;

import Entidades.Pais;
import Utilidades.Comparadores;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
//import java.util.TreeSet;

/**
     Se requiere un programa que lea y guarde países, y para evitar que se
     * ingresen repetidos usaremos un conjunto. El programa pedirá un país en un
     * bucle, se guardará el país en el conjunto y después se le preguntará al
     * usuario si quiere guardar otro país o si quiere salir, si decide salir,
     * se mostrará todos los países guardados en el conjunto. (Recordemos hacer
     * los servicios en la clase correspondiente)
     */

public class PaisService {
    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    public HashSet<Pais> ListadoPaises = new HashSet<Pais>();
    public Pais crearPais(){            
        Pais p = new Pais();
        System.out.println("Ingrese el nombre del país:  ");
        p.setNombrePais(leer.next());
        return p;
    }

    public void agregarPais() {

        String op = "";
        do {
            Pais pa= crearPais();
            ListadoPaises.add(pa);
            System.out.println("¿Desea agregar mas paises? S/N");
            op = leer.next();

        } while (op.equalsIgnoreCase("S"));
        System.out.println("---------------------- LISTA DE PAISES ----------------------");
        System.out.println(ListadoPaises.toString());
          
    }
    
    /**
     * Después deberemos mostrar el conjunto ordenado alfabéticamente: para esto
     * recordar cómo se ordena un conjunto.
     */
    public void mostrarPaisesOrdenadosAlfab(){
        
        List<Pais> Paises = new ArrayList(ListadoPaises);
        Collections.sort(Paises, Comparadores.odenarPortituloAsc);
        for (Pais auxiliar : Paises) {
            System.out.println(auxiliar);  
        }
        
    }
/**
 * Por último, al usuario se le pedirá un país y se recorrerá el conjunto
     * con un Iterator, se buscará el país en el conjunto y si está en el
     * conjunto se eliminará el país que ingresó el usuario y se mostrará el
     * conjunto. Si el país no se encuentra en el conjunto se le informará al
     * usuario.
 */    
    
    public void eliminarPais() {
        Iterator<Pais> iterador = ListadoPaises.iterator();
        Boolean queloque = false;
        System.out.println("Ingrese el país que desea eliminar:   ");
        String eliminar = leer.next();
        while (iterador.hasNext()) {
            Pais next = iterador.next();
            if (next.getNombrePais().equalsIgnoreCase(eliminar)) {
                iterador.remove();
                queloque = true;
            }
        }
        if (!queloque) {
            System.out.println("no ta el paí");
        } else {
            System.out.println("El paí contró y ya fue");
        }
        mostrarPaisesOrdenadosAlfab();
    } 
    
}
