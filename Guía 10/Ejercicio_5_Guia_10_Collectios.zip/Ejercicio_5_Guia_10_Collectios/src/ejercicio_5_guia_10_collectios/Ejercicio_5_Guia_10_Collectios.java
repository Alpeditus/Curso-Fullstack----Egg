/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ejercicio_5_guia_10_collectios;

import Servicio.PaisService;

/**
 *
 * @author joako
 */
public class Ejercicio_5_Guia_10_Collectios {

    /**
  Se requiere un programa que lea y guarde países, y para evitar que se
     * ingresen repetidos usaremos un conjunto. El programa pedirá un país en un
     * bucle, se guardará el país en el conjunto y después se le preguntará al
     * usuario si quiere guardar otro país o si quiere salir, si decide salir,
     * se mostrará todos los países guardados en el conjunto. (Recordemos hacer
     * los servicios en la clase correspondiente)
     */
    public static void main(String[] args) {
       
        PaisService servicio = new PaisService();
        
        servicio.agregarPais();
        servicio.mostrarPaisesOrdenadosAlfab();
        servicio.eliminarPais();
    }
    
}
