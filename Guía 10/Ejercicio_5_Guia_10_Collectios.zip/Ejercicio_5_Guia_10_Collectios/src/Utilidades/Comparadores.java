/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilidades;

import Entidades.Pais;
import java.util.Comparator;

/**
 *
 * @author joako
 */
public class Comparadores {
    
     public static Comparator<Pais> odenarPortituloAsc = new Comparator<Pais>() {
        @Override
        public int compare(Pais t1, Pais t2) {
            return t1.getNombrePais().compareTo(t2.getNombrePais());
        }
    };
    
}
