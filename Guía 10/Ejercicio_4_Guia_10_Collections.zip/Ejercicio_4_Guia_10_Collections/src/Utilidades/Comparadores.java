/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Utilidades;

import Entidades.Pelicula;
import java.util.Comparator;

/**
 *
 * 
 */
public class Comparadores {
    
public static Comparator<Pelicula> odenarPorDuracionAscendente = (Pelicula m1, Pelicula m2) -> ((Double) m2.getHoras()).compareTo(m1.getHoras());
    
    
    public static Comparator<Pelicula> odenarPorDuracionDescendente = (Pelicula m1, Pelicula m2) -> ((Double) m1.getHoras()).compareTo(m2.getHoras());
    
 
    public static Comparator<Pelicula> odenarPortituloAsc = new Comparator<Pelicula>() {
        @Override
        public int compare(Pelicula t1, Pelicula t2) {
            return t1.getTitulo().compareTo(t2.getTitulo());
        }
    };
    public static Comparator<Pelicula> odenarDirectorAsc = new Comparator<Pelicula>() {
        @Override
        public int compare(Pelicula t1, Pelicula t2) {
            return t1.getDirector().compareTo(t2.getDirector());
        }
    };
    
}
            
