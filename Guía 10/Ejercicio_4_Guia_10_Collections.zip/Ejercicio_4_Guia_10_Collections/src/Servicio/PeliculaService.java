/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Servicio;

import Entidades.Pelicula;
import Utilidades.Comparadores;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

/**
 * En el servicio deberemos tener un bucle que crea un objeto Pelicula
 * pidiéndole al usuario todos sus datos y guardándolos en el objeto Pelicula.
 * Después, esa Pelicula se guarda una lista de Peliculas y se le pregunta al
 * usuario si quiere crear otra Pelicula o no.
 *
 */
public class PeliculaService {

    Scanner leer = new Scanner(System.in).useDelimiter("\n");
    Scanner leerN = new Scanner(System.in);
    private List<Pelicula> listadoPeliculas = new ArrayList<>();

    public Pelicula crearPelicula() {

        Pelicula p = new Pelicula();
        System.out.println("Ingrese el nombre de la película:  ");
        p.setTitulo(leer.next());
        System.out.println("Ingrese el nombre del director de la película:  ");
        p.setDirector(leer.next());
        System.out.println("Ingrese la duración en horas  de la película:  ");
        p.setHoras(leerN.nextDouble());
        return p;
    }

    public void agregarPeliculas() {

        String op = "";
        do {
            Pelicula pe = crearPelicula();
            listadoPeliculas.add(pe);
            System.out.println("¿Desea agregar mas peliculas? S/N");
            op = leer.next();

        } while (op.equalsIgnoreCase("S"));
        System.out.println("---------------------- LISTADO DE PELICULAS ACTUALIZADO ----------------------");
        for (Pelicula aux : listadoPeliculas) {
            System.out.println(aux);
        }

    }

    /**
     * Mostrar peliculas
     */
    public void mostrarPeliculas() {

        for (Pelicula aux : listadoPeliculas) {
            System.out.println(aux);
        }
    }

    /**
     * • Mostrar en pantalla todas las películas con una duración mayor a 1
     * hora.
     */
    public void mostrarPelisMasUnaHora() {

        boolean buscar = false;
        for (int i = 0; i < listadoPeliculas.size(); i++) {
            Pelicula p1 = listadoPeliculas.get(i);
            if (p1.getHoras() > 1) {
                System.out.println("Mostrando películas mayores a una hora: ");
                System.out.println(p1.getTitulo());
                System.out.println(p1.getDirector());
                System.out.println(p1.getHoras());
                buscar = true;
            }
        }
        if (!buscar) {
            System.out.println();
            System.out.println("No se encontro ninguna pelicula con duracion mayor a una hora");
        }

    }

    public void ordenarPorDuracionAscendente() {

        System.out.println("**************Ordenando por duración, de menor a mayor ************** ");

        Collections.sort(listadoPeliculas, Comparadores.odenarPorDuracionAscendente);
        mostrarPeliculas();
    }

    public void ordenarPorDuracionDescendente() {

        System.out.println("**************Ordenando por duración, de mayor a menor**************");

        Collections.sort(listadoPeliculas, Comparadores.odenarPorDuracionDescendente);
        mostrarPeliculas();
    }

    public void ordenarPorTitulo() {

        System.out.println("**************Ordenando alfabéticamente por Título**************");

        Collections.sort(listadoPeliculas, Comparadores.odenarPortituloAsc);
        mostrarPeliculas();
    }

    public void ordenarPorDirector() {

        System.out.println("**************Ordenando alfabéticamente según el nombre del director**************");

        Collections.sort(listadoPeliculas, Comparadores.odenarDirectorAsc);
        mostrarPeliculas();
    }

    public void todosLosMetodos(){
        agregarPeliculas();
        mostrarPeliculas();
        mostrarPelisMasUnaHora();
        ordenarPorDuracionAscendente();
        ordenarPorDuracionDescendente();
        ordenarPorTitulo();
        ordenarPorDirector();
        todosLosMetodos();     
    }
}
    

