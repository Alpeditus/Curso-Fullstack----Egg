/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Entidades;

/**
 *
 * @author male_
 */
 public class Polideportivo extends Edificio {
    
    public String nombre;
    public boolean techado;

    public Polideportivo() {
    }

    public Polideportivo(String nombre, boolean techado, double ancho, double alto, double largo) {
        super(ancho, alto, largo);
        this.nombre = nombre;
        this.techado = techado;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public boolean isTechado() {
        return techado;
    }

    public void setTechado(boolean techado) {
        this.techado = techado;
    }
    
    public boolean getTecho(){
        return this.techado;
    }

    @Override
    public void calcularSuperficie() {
        
        System.out.println("La superficie del polodeportivo es: "+largo*ancho);      
    }

    @Override
    public void calcularVolumen() {
        if (techado==true) {
            System.out.println("El volumen del polideportivo es: "+largo*ancho*alto);   
        }  
    }    
}
