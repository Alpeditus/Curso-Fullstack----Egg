package javaapplication3.dao;

import java.util.ArrayList;
import java.util.List;
import javaapplication3.model.UserEntity;


public class UserDao extends Dao<UserEntity,Long>{
    
    public List<UserEntity> findByUserName(String username){
        conect();
        List<UserEntity> lista = em.createQuery("SELECT u FROM UserEntity u WHERE u.username = :user").setParameter("user", username).getResultList();
        disconect();
        return lista;
    }
    
    public List<UserEntity> findByUserNameAndEmail(String username, String email){
        List<UserEntity> lista = new ArrayList();
        conect();
        
        lista = (List<UserEntity>) em.createQuery("SELECT u FROM UserEntity u WHERE u.username = :user and u.email = :email")
                                                                    .setParameter("user", username)
                                                                    .setParameter("email", email)
                                                                    .getResultList();
        disconect();
        return lista;
    }
    
}
