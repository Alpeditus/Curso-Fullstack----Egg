package javaapplication3.dao;

import java.util.List;
import javaapplication3.model.UserEntity;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class Dao <T,L> {
    
    protected EntityManagerFactory emf = Persistence.createEntityManagerFactory("JavaApplication3PU");
    protected EntityManager em = emf.createEntityManager();
    
    protected void conect(){
        if (!em.isOpen()){
            em = emf.createEntityManager();
        }
    }
    
    protected void disconect(){
        if (em.isOpen()){
            em.close();
        }
    }
    
    public void create(T t){
        conect();
        em.getTransaction().begin();
        em.persist(t);
        em.getTransaction().commit();
        disconect();
    }
    
    public void update(T t){
        conect();
        em.getTransaction().begin();
        em.merge(t);
        em.getTransaction().commit();
        disconect();
    }
    
    public void delete (T t){
        conect();
        em.getTransaction().begin();
        em.remove(t);
        em.getTransaction().commit();
        disconect();
    }
    
    public UserEntity findById(Long id){
        conect();
        return em.find(UserEntity.class, id);
    }
    
    public List<T> findAll(String clas){
        conect();
        List<T> list = em.createQuery("SELECT u FROM "+clas+" u").getResultList();
        disconect();
        return list;
    }
    
}
