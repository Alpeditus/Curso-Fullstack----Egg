package javaapplication3;

import javaapplication3.model.UserEntity;
import javaapplication3.services.UserService;

public class JavaApplication3 {

    public static void main(String[] args) {
        
        UserService userService = new UserService();
        
//        UserEntity userEntity = new UserEntity(3l,"luciano","123456789","luciano@mail.com",2);
        
//        userService.create(userEntity);
        
        for (UserEntity userEntity1 : userService.findAll()) {
            System.out.println(userEntity1);
        }
        
        
//        System.out.println(userService.findById(2l));
        
//        for (UserEntity userEntity1 : userService.findByUserName("luciano")) {
//            System.out.println(userEntity1);
//        }
//        for (UserEntity userEntity1 : userService.findByUserNameAndEmail("luciano","luciano@mail.com")) {
//            System.out.println(userEntity1);
//        }

//        UserEntity user = userService.findById(2l);
//        user.setUsername("malenaModificado");
//        userService.update(user);

        System.out.println("Salio todo bien pichon!");
    }
    
}
