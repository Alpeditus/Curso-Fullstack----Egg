package javaapplication3.services;

import java.util.List;
import javaapplication3.dao.UserDao;
import javaapplication3.model.UserEntity;


public class UserService {
    UserDao userDao = new UserDao();

    public void create(UserEntity userEntity){
        userDao.create(userEntity);
    }

    public void update(UserEntity userEntity){
        userDao.update(userEntity);
    }

    public void delete(Long id){
        UserEntity userEntity = (UserEntity) userDao.findById(id);
        if (userEntity != null){
            userDao.delete(userEntity);
        }else{
            System.out.println("No existe el registro");
        }
    }

    public UserEntity findById(Long id){
        return (UserEntity) userDao.findById(id);
    }

    public List<UserEntity> findAll(){
        return userDao.findAll("UserEntity");
    }

    public List<UserEntity> findByUserName(String username){
        return userDao.findByUserName(username);
    }

    public List<UserEntity> findByUserNameAndEmail(String username, String email){
        return userDao.findByUserNameAndEmail(username, email);
    }

}
